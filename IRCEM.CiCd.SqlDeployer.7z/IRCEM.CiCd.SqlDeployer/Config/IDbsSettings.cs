﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface IDbsSettings
{
    string DbParDefaut { get; }

    IEnumerable<IDbSettings> Default { get; }

    IEnumerable<IDbSettings> Developement { get; }

    IEnumerable<IDbSettings> Recette { get; }

    IEnumerable<IDbSettings> Qualification { get; }

    IEnumerable<IDbSettings> PreProduction { get; }

    IEnumerable<IDbSettings> Production { get; }
}
