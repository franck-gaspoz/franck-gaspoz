﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface IDeploiementSQLSettings
{
    string CheminDeploiementDepot { get; }

    string CheminScriptsSQL { get; }

    string Depot { get; }

    string LoginDepot { get; }

    string PasswordDepot { get; }

    string BrancheDepot { get; }

    IDbsSettings Dbs { get; }

    IScriptsSettings Scripts { get; }

    string GitFetchRepoCommand { get; }

    string GitTagCommand { get; }

    string GitPushTagCommand { get; }

    string GitCommandPath { get; }

    string RmDirCommand { get; }

    string RmDirCommandPath { get; }
}
