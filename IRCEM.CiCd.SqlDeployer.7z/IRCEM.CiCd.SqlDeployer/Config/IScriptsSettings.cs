﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface IScriptsSettings
{
    IDbScriptsSettings? Postgresql { get; }

    IDbScriptsSettings? SqlServer { get; }
}
