﻿using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Config;

static class ConfigExtensions
{
    public static TypesDbs ToTypeDb(
        this IDbSettings dbSettings,
        Error error)
        => Enum.TryParse<TypesDbs>(
            dbSettings.Type, out var typeDb)
            ? typeDb
            : throw error.Argument(
                "ValeurNonDansLEnum",
                dbSettings.Type,
                typeof(TypesDbs).Name);

    public static Environements ToEnvironement(
        this string environement,
        Error error)
        => Enum.TryParse<Environements>(
            environement, out var envirEnum)
            ? envirEnum
            : throw error.Argument(
                "ValeurNonDansLEnum",
                environement,
                typeof(Environements).Name);
}
