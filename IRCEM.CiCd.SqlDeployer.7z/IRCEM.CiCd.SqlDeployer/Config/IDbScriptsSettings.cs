﻿namespace IRCEM.CiCd.SqlDeployer.Config;

public interface IDbScriptsSettings
{
    string CreateTableHistorique { get; }

    string DropTableHistorique { get; }

    string InsertTableHistorique { get; }
}
