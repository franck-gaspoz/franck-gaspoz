﻿using CommandLine.NetCore.Services.CmdLine;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

using Microsoft.Extensions.DependencyInjection;

namespace IRCEM.CiCd.SqlDeployer;

public class Program
{
    /// <summary>
    /// command line input
    /// <para>commandName ( option (optionValue)* | parameter )* globalOption*</para>
    /// </summary>
    /// <param name="args">arguments</param>
    /// <returns>status code</returns>
    public static int Main(string[] args)
        => new CommandLineInterfaceBuilder()
            .UseBuildDelegate(
                hostBuilder =>
                    hostBuilder.ConfigureServices(
                        (hostBuilderContext, services) =>
                            services
                                .AddSingleton<ConfigManager>()
                                .AddSingleton<Error>()
                                .AddSingleton<CommandServices>()
                                .AddSingleton<GitRepository>()
                                .AddSingleton<HistoriqueForEnvAndDbBuilder>()
                    )
            )
            .Build(args)
            .Run();
}
