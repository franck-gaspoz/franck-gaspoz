﻿namespace IRCEM.CiCd.SqlDeployer.Services.Config;
enum TypesDbs
{
    Postgresql,
    SqlServer
}
