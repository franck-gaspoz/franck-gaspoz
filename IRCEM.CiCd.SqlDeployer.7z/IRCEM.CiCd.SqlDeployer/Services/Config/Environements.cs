﻿namespace IRCEM.CiCd.SqlDeployer.Services.Config;

/// <summary>
/// valeurs d'environements
/// </summary>
enum Environements
{
    Default,
    Developement,
    Recette,
    Qualification,
    PreProduction,
    Production
}
