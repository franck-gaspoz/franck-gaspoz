﻿// #define Check_Numeros_Scripts_Contigus
// actuellement non: possibilité de supprimer des scripts du repo pour qu'il ne soient pas relivrés

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;

class SQLScripts
{
    /// <summary>
    /// liste des scripts sqls
    /// </summary>
    public IReadOnlyList<SQLScript> List
        => _list;

    readonly List<SQLScript> _list = new();

    public SQLScripts(string defaultDb, IEnumerable<FileInfo> fileInfos, Error error)
    {
        foreach (var fileInfo in fileInfos)
            _list.Add(
                new SQLScript(
                    defaultDb,
                    fileInfo,
                    error,
                    File.ReadAllText(
                        fileInfo.FullName)));

        Validate(error);
    }

    public SQLScript? Get(string dbId, int number, bool isRollback)
        => _list
            .Where(
                x => x.Number == number
                && x.DbId == dbId
                && x.IsRollback == isRollback)
            .FirstOrDefault();

    public IEnumerable<string> GetDbIds()
        => _list
            .Select(x => x.DbId)
            .Distinct();

    public IEnumerable<SQLScript> GetScriptsByDb(string dbId)
        => _list
            .Where(x => x.DbId == dbId)
            .OrderBy(x => x.Number);

    public IEnumerable<SQLScript> GetUpdates(string dbId, int number)
        => _list
            .Where(x => !x.IsRollback
                && x.DbId == dbId
                && x.Number > number)
            .OrderBy(x => x.Number);

    public IEnumerable<SQLScript> GetRollbacks(string dbId, int number)
        => _list
            .Where(x => x.IsRollback
                && x.DbId == dbId
                && x.Number > number)
            .OrderByDescending(x => x.Number);

    public void Validate(Error error)
    {
        if (!_list.Any())
            return;

        foreach (var dbId in GetDbIds())
        {
            // vérifie que chaque script d'update à un rollback
            foreach (var script in _list.Where(x => !x.IsRollback))
            {
                if (Get(dbId, script.Number, true) is null)
                    throw error.Argument("ScriptSansRollback", script);
            }

            // vérifie que chaque script de rollback à un update
            foreach (var script in _list.Where(x => x.IsRollback))
            {
                if (Get(dbId, script.Number, false) is null)
                    throw error.Argument("ScriptSansUpdate", script);
            }

            var dbScripts = GetScriptsByDb(dbId);

            // vérifie que les numéros de scripts commencent bien à 0
            if (dbScripts.Select(x => x.Number).Distinct().Min() != 0)
                throw error.Argument("ScriptsPasAZero");

#if Check_Numeros_Scripts_Contigus
            // vérifie que les numéros de scripts sont bien contigus
            var nMoinsUn = -1;
            foreach (var n in dbScripts.OrderBy(x => x.Number).Select(x => x.Number).Distinct())
            {
                if (n != nMoinsUn + 1)
                    throw error.Argument("NumerotationScriptsNonContigue", n);
                nMoinsUn = n;
            }
#endif
        }
    }
}
