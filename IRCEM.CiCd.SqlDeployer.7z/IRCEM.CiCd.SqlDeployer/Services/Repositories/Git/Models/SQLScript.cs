﻿using System.Diagnostics;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;

[DebuggerDisplay("{_debuggerDisplay}")]
sealed class SQLScript
{
    public int Number { get; private set; }

    public string DbId { get; private set; }

    public bool IsRollback { get; private set; }

    public string SQL { get; private set; }

    public FileInfo FileInfo { get; private set; }

    string? _description;
    public string Description { 
        get
        {
            if (_description is null)
            {
                var lines = File.ReadAllLines(
                    FileInfo.FullName);
                _description = lines.Any() ? lines[0] 
                    : string.Empty;
            }
            return _description;        
        } 
    }

    string _debuggerDisplay => ToString();

    public SQLScript(
        string defaultDb,
        FileInfo fileInfo,
        Error error,
        string sql)
    {
        FileInfo = fileInfo;
        SQL = sql;
        DbId = defaultDb;
        var parts = fileInfo.Name.Split('.');
        if (parts.Length < 2 || parts.Length > 4 || parts.Last() != "sql")
            throw error.Argument("FormatNomScriptInvalide", fileInfo.Name);
        try
        {
            Number = Convert.ToInt32(parts[0]);
        }
        catch
        {
            throw error.Argument("NumeroDeScriptInvalide", parts[0]);
        }
        if (parts.Length == 3)
        {
            IsRollback = parts[1] == "rollback" ? true : throw error.Argument("FormatNomScriptInvalide", fileInfo.Name);
        }
        if (parts.Length == 4)
        {
            IsRollback = parts[2] == "rollback" ? true : throw error.Argument("FormatNomScriptInvalide", fileInfo.Name);
            DbId = parts[1];
        }
    }

    public override string ToString()
        => $"(invon){Number} ({DbId}){(IsRollback ? " rollback" : "")} | {Description}(tdoff)";

}
