﻿using IRCEM.CiCd.SqlDeployer.Commands;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Process;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;

class GitRepository
{
    readonly ConfigManager _configManager;
    readonly Error _error;
    SQLScripts? _sqlScripts;

    public SQLScripts SqlScripts
    {
        get => _sqlScripts is null ? throw _error.Argument("ScriptsNonCharges") : _sqlScripts;
        private set => _sqlScripts = value;
    }

    public string RepositoryPath
    {
        get
        {
            var path = _configManager.Settings.DeploiementSQL.CheminDeploiementDepot;
            if (Path.IsPathFullyQualified(path))
                return path;
            else
                Path.Combine(
                    Environment.CurrentDirectory,
                    path
                    );
            return path;
        }
    }

    public string SQLScriptsPath =>
        Path.Combine(
            RepositoryPath,
            _configManager.Settings.DeploiementSQL.CheminScriptsSQL
            );

    public GitRepository(
        ConfigManager configManager,
        Error error)
        => (_configManager, _error) = (configManager, error);

    public void InitRepository(IOutput output, bool noFetch)
    {
        output.OutputSection(output.T("InitialisationDepot", _configManager.Settings.DeploiementSQL.Depot));

        output.OutputAction(output.T("FetchRepository"),
            _configManager.Settings.DeploiementSQL.Depot);
        output.OutputAction(output.T("FetchRepositoryIn"), SQLScriptsPath);

        if (!noFetch)
        {
            Fetch(output);
            output.OutputActionHighlight(output.T("DepotRecupere"));
        }
        else
            output.OutputWarning(output.T("EtapeIgnoree"));

        LoadScripts(output);
    }

    public void Tag(IOutput output, string build, bool noTag)
    {
        output.OutputSection(output.T("TagLeDepot", build));

        if (noTag)
        {
            output.OutputWarning(output.T("EtapeIgnoree"));
            return;
        }

        var tagRes = RunProcess(
            _configManager.Settings.DeploiementSQL.GitTagCommand,
            _configManager.Settings.DeploiementSQL.GitCommandPath,
            RepositoryPath,
            output,
            new Dictionary<string, string>(){
                { "{build}" , build }},
            true);
        // tagRes == 128 si tag déjà présent

        var pushTagRes = RunProcess(
            _configManager.Settings.DeploiementSQL.GitPushTagCommand,
            _configManager.Settings.DeploiementSQL.GitCommandPath,
            RepositoryPath,
            output,
            new Dictionary<string, string>(){
                { "{build}" , build }},
            true);

        if (tagRes == 0 && pushTagRes == 0)
            output.OutputActionHighlight(output.T("RepoTagge"));
        else
            output.OutputWarning(output.T("ErrorTagDepot"));
    }

    public void Fetch(IOutput output)
    {
        var path = RepositoryPath;
        if (Directory.Exists(path))
            RunProcess(
                _configManager.Settings.DeploiementSQL.RmDirCommand,
                _configManager.Settings.DeploiementSQL.RmDirCommandPath,
                Environment.CurrentDirectory,
                output,
                new Dictionary<string, string>(){
                    { "{targetPath}" , path }
                    });

        Directory.CreateDirectory(path);
        RunProcess(
            _configManager.Settings.DeploiementSQL.GitFetchRepoCommand,
            _configManager.Settings.DeploiementSQL.GitCommandPath,
            Environment.CurrentDirectory,
            output,
            new Dictionary<string, string>(){
                { "{repoUrl}",_configManager.Settings.DeploiementSQL.Depot },
                { "{targetPath}" , path },
                { "{branch}" , _configManager.Settings.DeploiementSQL.BrancheDepot }
                },
            true);
    }

    public void LoadScripts(IOutput output)
    {
        if (!Directory.Exists(RepositoryPath))
            throw _error.Argument("DepotIntrouvable", RepositoryPath);
        if (!Directory.Exists(SQLScriptsPath))
            throw _error.Argument("ScriptsIntrouvables", SQLScriptsPath);

        output.OutputAction(output.T("AnalyseScripts"));

        var scripts = Directory.EnumerateFiles(SQLScriptsPath, "*.sql");

        SqlScripts = new(
            _configManager.Settings.DeploiementSQL.Dbs.DbParDefaut,
            scripts.Select(x => new FileInfo(x)),
            _error
            );

        output.OutputActionHighlight(output.T("AnalyseScriptsOk"));
    }

    int RunProcess(
        string cmdLine,
        string commandPath,
        string workingDirectory,
        IOutput output,
        Dictionary<string, string> parameters,
        bool invertOutputChannels = false)
    {
        var parts = cmdLine.Split(' ');
        var cmd = parts[0];
        var args = parts[1..];

        foreach (var kvp in parameters)
            Replace(args, kvp.Key, kvp.Value);

        var cmdArgs = string.Join(' ', args);
        output.OutputTrace("running: " + cmd + " " + cmdArgs);

        void OutStream(string str) => output.OutputProcess(str);
        void ErrStream(string str) => output.GetConsole().Logger.LogError(str);

        var retCode = ProcessWrapper.RunProcess(
            cmd,
            commandPath,
            workingDirectory,
            true,
            invertOutputChannels ? ErrStream : OutStream,
            invertOutputChannels ? OutStream : ErrStream,
            cmdArgs);

        output.OutputTrace(output.T("CommandeTerminee", retCode));

        return retCode;
    }

    static void Replace(string[] array, string search, string replace)
    {
        for (var i = 0; i < array.Length; i++)
        {
            if (array[i] == search)
                array[i] = replace;
        }
    }
}
