﻿using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

sealed class Historiques
{
    public IReadOnlyDictionary<Environements, List<HistoriqueForEnvAndDb>>
        ByEnv => _historiquesByEnv;

    readonly Dictionary<Environements, List<HistoriqueForEnvAndDb>> _historiquesByEnv = new();

    public void AddEnv(
        Environements env,
        IEnumerable<HistoriqueForEnvAndDb> historiques)
        => _historiquesByEnv.Add(env, historiques.ToList());

    public void Clear() => _historiquesByEnv.Clear();
}
