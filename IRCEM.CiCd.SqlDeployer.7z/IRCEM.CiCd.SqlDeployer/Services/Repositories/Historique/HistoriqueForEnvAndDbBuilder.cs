﻿using IRCEM.CiCd.SqlDeployer.Config;
using IRCEM.CiCd.SqlDeployer.Services.Config;

namespace IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

sealed class HistoriqueForEnvAndDbBuilder
{
    readonly ConfigManager _configManager;
    readonly Error _error;

    public IReadOnlyCollection<HistoriqueForEnvAndDb> List
        => _list;

    readonly List<HistoriqueForEnvAndDb> _list = new();
    Environements? _env;

    public HistoriqueForEnvAndDbBuilder(
        ConfigManager configManager,
        Error error
        )
        => (_configManager, _error) = (configManager, error);

    public HistoriqueForEnvAndDbBuilder AddHistoriqueRepositoryForEnvAndDb(Environements env)
    {
        _env = env;
        _list.Clear();
        foreach (var db in _configManager.GetDbSettings(env))
        {
            var historique = new HistoriqueRepository(
                    _configManager,
                    db.ToTypeDb(_error),
                    db.Connexion
                    );
            _list.Add(new(historique, db, env));
        }
        return this;
    }

    public Historiques Build(Historiques historiques)
    {
        historiques.AddEnv(_env!.Value, _list);
        return historiques;
    }
}
