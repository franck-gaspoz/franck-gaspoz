﻿using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Arguments.GlobalOpts;
using CommandLine.NetCore.Services.Text;

using Microsoft.Extensions.Configuration;

namespace IRCEM.CiCd.SqlDeployer.Commands.GlobalOpts;

sealed class Debug : GlobalOpt
{
    public Debug(
        IConfiguration config,
        Texts texts,
        ValueConverter valueConverter)
        : base(config, texts, valueConverter)
    {
    }
}
