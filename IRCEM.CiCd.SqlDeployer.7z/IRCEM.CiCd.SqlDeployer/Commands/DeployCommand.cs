﻿using System.Web;

using CommandLine.NetCore.Services.CmdLine.Arguments;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

namespace IRCEM.CiCd.SqlDeployer.Commands;

abstract class DeployCommand : AbstractCommand
{
    protected List<Environements> Envs = new();
    protected string Build = string.Empty;
    protected bool Simule;
    protected bool NoFetch;
    protected string? DumpSql;
    protected readonly GitRepository GitRepo;
    protected readonly Historiques Historiques = new();
    protected readonly HistoriqueForEnvAndDbBuilder HistoEnvDbBuilder;

    public DeployCommand(
        CommandServices services,
        GitRepository gitRepo,
        HistoriqueForEnvAndDbBuilder histoEnvDbBuilder) : base(services)
        => (GitRepo, HistoEnvDbBuilder) = (gitRepo, histoEnvDbBuilder);

    protected void InitOpts(
        Opt<List<Environements>> envOpt,
        Opt<string> buildOpt,
        Opt noFetchOpt,
        Opt simuleOpt,
        Opt<string> DumpSqlOpt)
    {
        Envs = GetEnv(envOpt);
        Build = GetBuild(buildOpt);
        (Simule, NoFetch, DumpSql) =
            (simuleOpt.IsSet, noFetchOpt.IsSet, DumpSqlOpt.IsSet ? DumpSqlOpt.GetValue() : null);

        if (DebugEnabled)
        {
            DumpVar("environements", string.Join(',', Envs));
            DumpVar("build", Build);
            DumpVar("simule", Simule + "");
            DumpVar("noFetch", NoFetch + "");
            DumpVar("dumpSql", DumpSql + "");
        }

        if (DumpSql is not null)
        {
            var handle = File.OpenHandle(DumpSql, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
            handle.Close();
        }
    }

    protected void SaveUpdates(
        Func<HistoriqueForEnvAndDb, 
        List<SQLScript>> getUpdates)
    {
        foreach (var env in Envs)
        {
            OutputSection(T("InitialisationHistorique", env));

            foreach (var historique in Historiques.ByEnv[env])
            {
                var updates = getUpdates(historique)!;

                if (DumpSql is not null)
                {
                    foreach (var update in updates)
                    {
                        var lines = new List<string>
                    {
                        string.Empty,
                        string.Empty,
                        $"-- script #{update.Number}",
                        string.Empty
                    };

                    File.AppendAllLines(DumpSql, lines);

                    File.AppendAllText(
                        DumpSql,
                        update.SQL);
                    }
                }
                
                RunTask(SaveUpdatesForEnvironement(
                    Build,
                    updates,
                    historique));
            }
        }
    }

    protected async Task SaveUpdatesForEnvironement(
        string build,
        List<SQLScript> updates,
        HistoriqueForEnvAndDb historique)
    {
        OutputAction(T("MiseAJourHistorique"));

        foreach (var scriptSQL in updates)
            OutputTrace(scriptSQL.ToString());

        if (Simule)
            OutputWarning(T("EtapeIgnoree"));

        try
        {
            await historique.Repository
                .AddUpdates(
                    build, 
                    updates,
                    Simule,
                    DumpSql);

            OutputActionHighlight(T("HistoriqueMisAJour"));
        }
        catch (Exception updateException)
        {
            if (updateException.InnerException is null)
                throw;
            throw updateException.InnerException;
        }
    }

    protected void InitEnvironementsAndRunScripts(
        Func<HistoriqueForEnvAndDb, List<SQLScript>> getUpdates)
    {
        Historiques.Clear();
        foreach (var env in Envs)
        {
            OutputSection(T("InitialisationEnv", env));
            HistoEnvDbBuilder
                .AddHistoriqueRepositoryForEnvAndDb(env)
                .Build(Historiques);

            foreach (var historique in Historiques.ByEnv[env])
            {
                OutputAction(T("CnxDbEnCours"), historique.Db.Id);
                OutputTrace(historique.Db.Connexion);

                var (exists, error) = RunTask<(bool, string?)>(historique.Repository.CheckExists());

                if (!exists)
                    throw Error.Argument("PasDHistoriquePourLEnv", env);
                else
                {
                    OutputAction(T("LectureHistorique", env));

                    var updates = getUpdates(historique);

                    if (!updates.Any())
                    {
                        OutputActionHighlight(T("DbAJour"));
                    }
                    else
                    {
                        OutputActionHighlight(T("ScriptsAJouer"));
                        foreach (var scriptSQL in updates)
                            OutputTrace(scriptSQL.ToString());

                        RunScripts(
                            historique,
                            updates);
                    }
                }
            }
        }
    }

    protected void RunScripts(
        HistoriqueForEnvAndDb historique,
        List<SQLScript> updates)
    {
        OutputSection(T("ExecScriptsSQL"));

        OutputAction(T("OpenTransac"));

        using var scope = AmbiantTransaction.New();

        foreach (var script in updates)
        {
            OutputAction(T("RunningScript", script));

            if (!Simule)
                RunTaskWithSQLTrace(
                    historique
                        .Repository
                        .RunScript(script));
            else
                OutputWarning(T("EtapeIgnoree"));
        }

        OutputAction(T("CommitTransac"));

        scope.Complete();
    }
}
