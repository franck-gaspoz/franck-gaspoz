﻿using CommandLine.NetCore.Services.CmdLine.Arguments;
using CommandLine.NetCore.Services.CmdLine.Commands;

using IRCEM.CiCd.SqlDeployer.Services;
using IRCEM.CiCd.SqlDeployer.Services.Config;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Git.Models;
using IRCEM.CiCd.SqlDeployer.Services.Repositories.Historique;

namespace IRCEM.CiCd.SqlDeployer.Commands;

sealed class Update : DeployCommand
{
    bool _noTag;

    public Update(
        CommandServices services,
        GitRepository gitRepo,
        HistoriqueForEnvAndDbBuilder histoEnvDbBuilder) : base(
            services, gitRepo, histoEnvDbBuilder)
    { }

    protected override CommandResult Execute(ArgSet args) =>
        For()
        .Do(() => UpdateSQL)
        .Options(
            Opt<List<Environements>>("env"),
            Opt<string>("build"),
            Opt("no-fetch"),
            Opt("no-tag"),
            Opt("simule"),
            Opt<string>("dump-sql"))
        .With(args);

    void UpdateSQL(
        Opt<List<Environements>> envOpt,
        Opt<string> buildOpt,
        Opt noFetchOpt,
        Opt noTagOpt,
        Opt simuleOpt,
        Opt<string> dumpSqlOpt)
    {
        InitOpts(
            envOpt,
            buildOpt,
            noFetchOpt,
            simuleOpt,
            dumpSqlOpt
            );
        _noTag = noTagOpt.IsSet;

        if (DebugEnabled)
        {
            DumpVar("noTag", _noTag + "");
        }

        List<SQLScript> getUpdates(HistoriqueForEnvAndDb historique)
            => RunTask(
                historique.Repository
                    .GetUpdates(
                        GitRepo,
                        historique.Db.Id))
                .OrderBy(x => x.Number)
                .ToList();

        GitRepo.InitRepository(this, NoFetch);
        InitEnvironementsAndRunScripts(getUpdates);
        SaveUpdates(getUpdates);
        GitRepo.Tag(this, Build, _noTag | Simule);
    }
}
