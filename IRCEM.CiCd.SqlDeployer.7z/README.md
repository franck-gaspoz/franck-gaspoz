# IRCEM.CiCd.SqlDeployer
Deployeur de SQL | outil console | int�grable CI/CD
___

## expression du besoin:
- au moment du d�ploiement faire jouer les scripts sqls pour aligner la db avec la version du build
- update sql sur build + r�cent ou roolback sql sur build + ancien
- �ventuellement pr�voir un backup complet de db (dump binaire?)
- pouvoir fournir des scripts qui visent des dbs diff�rentes
- solution r�utilisable pour d'autres projets
- outil console qui peut fonctionner standalone hors ci/cd ou utilisation des variables d'env fournies par le .env en ci/cd

___

## synoptique:

1. chargement de la configuration des bases, et du projet git, numero du build en cours

2. pour chaque db

    2.1. r�cup�ration du num�ro de dernier script livr� et du num�ro de build (table qui devrait contenir l'historique des n� par build)

    2.2. extraction des scripts sql dans la branche concern�e par la plateforme de d�ploiement

    2.3. selon le num�ro de build, on d�termine si on fait un rollback (build en cours < build livr�)  de la livraison ou un update (build en cours >=). si build identique il n'y a rien a faire au niveau sql (identit�) et le programme se termine

    2.4. en cas d'update:
    - si possible faire un backup binaire de la db et l'archive
    - jouer les scripts concern�s dans un transaction et updater l'historique des livraisons sql dans la db
    - en cas d'erreur, renvoyer code + messages d'erreurs. dans la chaine ci/cd cela devrait avoir pour effet d'interrompre et mettre en �chec le d�ploiement
    - si pas fait par ailleurs et livraison effective, tagger le d�p�t avec le num�ro de build pour identifier l'�tat du code au moment de la livraison. si d�j� tagg� utiliser un tag avec un postfix incr�mental

    2.5. en cas de rollback:
    - bloquer la possiblit� en prod, indiquer les scripts a jouer et rendre un code d'erreur
    -  jouer les scripts concern�s dans un transaction et updater l'historique des livraisons sql dans la db
    - en cas d'erreur, renvoyer code + messages d'erreurs. dans la chaine ci/cd cela devrait avoir pour effet d'interrompre et mettre en �chec le d�ploiement

    2.6. en cas d'incoh�rence d�tect�e entre les numeros de scripts a livrer, le num�ro de build et l'historique des livraisons: arr�t imm�diat, retour messages des erreurs et code erreur

___

## Conception

### mod�les des donn�es:

#### historique des livraisons en db:
table: `LivraisonsSQL`

| id (autoincrement) | date | numero de build | numero de script (une entr�e pour chaque script jou�) | indique si rollback|
|----|----|----|----|----|


#### fichiers de livraison SQL:

`{numero}[.{dbId}][.rollback].sql`

l'id�e des fichiers SQL est d'apporter des modifications incr�mentales (updates ou rollbacks correspondants) a la base qui ne sont pas destructifs et prot�gent les donn�es et leur int�grit�, en correspondance avec les modifications du logiciel

- numero : identifiant unique du script, incr�ment� par ordre des updates. le num�ro `0` correspondant au script de cr�ation de la db (�tat initial avant tout update incr�mental)
- optionnel : .dbId qui indique un identifiant de db si plusieurs db et diff�rent de la db "par d�faut"
- .rollback si le script est un script de rollback, rien si le script est un script d'update sql

les fichiers sont � ranger dans un r�pertoire unique au sein d'un projet de la solution d�ploy�e et identifi� par la configuration.
par exemple: `Infrastructure/SQL/a-livrer`
on peut d�charger les fichiers livr�s pour simplifier la lecture de la liste des fichiers dans un r�pertoire d'archive: `Infrastructure/SQL/archive`

### donn�es de param�trage de la fonction de livraison:

* `chemin du d�ploiement du repo TFS` si auto d�ploiement
* `chemin des fichiers sql du repo TFS` (peut �tre d�j� r�cup�r�s si fonctionnement ci/cd sinon chemin de r�cup�ration si stand-alone)
* `adresse des fichiers du repo git` + `codes d'acces sinon SSPI` + `branche`
* couples `dbId` + `chaine de connexion � la db` (dbId `default` r�serv� pour les fichiers sql sans dbId)
* `numero de build` en cours de livraison
* `identifiant de l'environnement` en cours de d�ploiement: `developement`,`recette`,`qualif`,`preprod`,`prod`. on peut envisager d'accepter plusieurs environnements cibles � la fois
* `chemin d'archivage de la db` si fonctionnalit� disponible
* liste des noms de types de bases de donn�es support�es
* syntaxes SQL par types de bases support�es pour les op�rations requises par l'outil

### op�rations principales de l'application de livraison:
- initialiser une base d'un environnement pour support de la fonction de livraison (table LivraisonsSQL)
- r�aliser un update SQL
- r�aliser un rollback SQL
- lister l'�tat de livraison actuel d'une ou plusieurs cibles (build,numero de script,date,..)
- lister l'historique de livraison d'une ou plusieurs cibles
- fonctionner en mode simulation sur les op�rations update SQL/rollback SQL

### impl�mentation

- log de l'activit� d�taill�e du d�ployeur
- fonctionnement stand alone (applicaton console)
- pouvoir supporter diff�rents type de db (posgrsql,sqlserver,..)
- protection contre l'ex�cution en parrall�le
- settings locaux pour utilisation stand-alone et surcharg�s depuis le .env pour fonctionnement dans Jenkins
- comparer le d�ploiement entre deux ou plusieurs environnements
___

## R�alisation

### settings

exemple avec le cas du projet IDR

```json
{
    "DeploiementSQL":
    {
        "CheminDeploiementDepot" : "/repo",
        "CheminScriptsSQL" : "/GestionLiquidation.Infrastructure/SQL/� livrer",
        "Depot" : "http://tfs.gpsi.fr/tfs/DefaultCollection/IDR/_git/back-gestion-liquidation",
        "LoginDepot" : "",
        "PasswordDepot" : "",
        "NomVariableVersionBuild": "TAG_VERSION",
        "Dbs" : {
            "DbParDefaut": "idr",
            "Developement": {
                 "idr": {
                     "type": "postgresql",
                     "connexion": "Server=svdev1553.gpsi.fr;Port=7001;Database=idr;Uid=idr_user;Pwd=XXXXX;Include Error Detail=True;Timeout=30;CommandTimeout=30"
                 }
            },
            ...
            "Production": {
                ...
            }
        },
        "TypesDbs" : [ "postgresql" , "sqlserver" ],
        "Scripts":
        {
            "postgresql" :
            {
                "CreateTableHistorique": "CREATE TABLE \"HistoriqueSQL\" ( \"Id\" GENERATED BY DEFAULT AS IDENTITY NOT NULL,PRIMARY KEY (\"Id\"),\"Date\" timestamptz NOT NULL,\"Build\" character varying NOT NULL,\"Script\" integer NOT NULL, \"IsRollback\" boolean NOT NULL);" 
            },
            "sqlserver" :
            {
                "CreateTableHistorique": ""
            }
        }
    }
}
```

### exemple des fichiers de livraisons SQL et table d'historique:

```
r�pertoire /back-gestion-liquidation/GestionLiquidation.Infrastructure/SQL/� livrer :
0.rollback.sql
0.sql
1.rollback.sql
1.sql
```
le fichier d'index 0 correspond au script de cr�ation de la db et le le 0.rollback au script de destruction de la db
l'initialisation de la table d'historique de d�ploiement dans ce cas serait pour le numero de build 1.0.0 :

| Id | Date | Build | Script | IsRollback |
|----|----|----|----|----|
| 1 | 03/01/2023 | 1.0.0 | 0 | false |
| 2 | 03/01/2023 | 1.0.0 | 1 | false |

apr�s un update pour le build 1.0.1 contenant le script `2.sql` et sont pendant `2.rollback.sql` :

| Id | Date | Build | Script | IsRollback |
|----|----|----|----|----|
| 1 | 03/01/2023 | 1.0.0 | 0 | false |
| 2 | 03/01/2023 | 1.0.0 | 1 | false |
| 3 | 03/01/2023 | 1.0.1 | 2 | false |

et apr�s un rollback vers le build 1.0.0 :

| Id | Date | Build | Script | IsRollback |
|----|----|----|----|----|
| 1 | 03/01/2023 | 1.0.0 | 0 | false |
| 2 | 03/01/2023 | 1.0.0 | 1 | false |
| 3 | 03/01/2023 | 1.0.1 | 2 | false |
| 4 | 03/01/2023 | 1.0.0 | 2 | true |

### op�rations de la ligne de commande

#### `init --env {liste des envs s�par�s par ,} [--build {no build}] [--no-historique] [--no-fetch] [--no-tag]`
- initialise les dbs (fabrique la table d'historique de d�ploiement sql: `LivraisonsSQL`) pour les environements indiqu�s avec le no de build indiqu�
- si le n� de build n'est pas indiqu� il est pris dans la variable d'environement indiqu�e par le setting `NomVariableVersionBuild`
- r�cup�re le d�pot (sauf si `--no-fetch`, auquel cas il doit �tre d�j� pr�sent dans le r�pertoire configur�) selon les settings et tag avec le n� de build (sauf si `--no-tag` ou tag d�j� pr�sent)
- r�cup�re tous les fichiers de script SQL existants et inclu dans l'historique en db sauf si option `--no-historique`

#### `check --env {liste des envs s�par�s par ,} [--no-fetch]`
- indique la livraison a effectuer pour les environements list�s en analysant le delta entre les fichiers sql pr�sents dans le d�p�t et le contenu de la table d'historique des livraisons
- r�cup�re le d�pot (sauf si `--no-fetch`, auquel cas il doit �tre d�j� pr�sent dans le r�pertoire configur�)

pour retrouver la liste des fichiers livr�s depuis la table d'historique:
- identifier le build actuel:
```sql
SELECT "Build" FROM "HistoriqueSQL" ORDER BY "Id" DESC WHERE "IsRollback"=FALSE;
```
- le num�ro du dernier script livr� est alors:
```sql
SELECT MAX("Id") FROM "HistoriqueSQL" WHERE "Build"='buildCourant';
```
si le num�ro du dernier script livr� est N alors les scripts de 0 � N sont livr�s

#### `update --env {liste des envs s�par�s par ,} [--build {no build}] [--no-fetch] [--no-tag] [--simule]`
- met a jour les dbs des environements list�s pour le num�ro de build indiqu� avec le delta des fichiers sql pr�sents dans le d�p�t et les historiques de livraisons en bases de donn�es
- si le n� de build n'est pas indiqu� il est pris dans la variable d'environement indiqu�e par le setting 
- r�cup�re le d�pot (sauf si `--no-fetch`, auquel cas il doit �tre d�j� pr�sent dans le r�pertoire configur�) selon les settings et tag avec le n� de build (sauf si `--no-tag` ou tag d�j� pr�sent)
- r�cup�re tous les fichiers de script SQL existants et inclu dans l'historique en db et ex�cute les scripts sqls d'**update** selons les conventions sur les dbs concern�es
- si `--simule` ne modifie pas les bases mais indique tout de m�me les op�rations qui auraient �t� effectu�es

#### `rollback --env {liste des envs s�par�s par ,} [--build {no build}] [--no-fetch] [--no-tag] [--simule]`
- met a jour les dbs des environements list�s pour le num�ro de build indiqu� avec le delta des fichiers sql pr�sents dans le d�p�t et les historiques de livraisons en bases de donn�es
- si le n� de build n'est pas indiqu� il est pris dans la variable d'environement indiqu�e par le setting 
- r�cup�re le d�pot (sauf si `--no-fetch`, auquel cas il doit �tre d�j� pr�sent dans le r�pertoire configur�) selon les settings et tag avec le n� de build (sauf si `--no-tag` ou tag d�j� pr�sent)
- r�cup�re tous les fichiers de script SQL concern�s selon l'historique en db et le num�ro de build et ex�cute les scripts sqls de **rollback** selons les conventions sur les dbs concern�es. met � jour l'historique en cons�quence
-  si `--simule` ne modifie pas les bases mais indique tout de m�me les op�rations qui auraient �t� effectu�es

### Lancement depuis Jenkins

- le programme prend sa config dans `appSettings.json` qui est surcharg� par le `.env`
- l'environement est pris dans `CurrentEnvironement`
- le build est pris dans `TAG_VERSION`

la commande d'update SQL est alors:

```shell
IRCEM.CiCd.SqlDeployer update
```
ou avec des traces:

```shell
IRCEM.CiCd.SqlDeployer update --debug
```
ou si le dep�t ne doit pas �tre ni tir� ni tagg�

```shell
IRCEM.CiCd.SqlDeployer update -no-fetch --no-tag
```

